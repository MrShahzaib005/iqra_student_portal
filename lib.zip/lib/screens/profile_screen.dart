import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('MY PROFILE', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
          
            child: Image.asset('assets/logo.png', width: 100), 
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              const SizedBox(height: 20),
              
              Stack(
                alignment: Alignment.bottomRight,
                children: [
                  const CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage('assets/profile.jpg'),
                  ),
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.blue,
                      shape: BoxShape.circle,
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.camera_alt, size: 20, color: Colors.white),
                      onPressed: () {
                        // Logic to upload new photo
                      },
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 10),
              const Text(
                'Welcome, Ahmed!',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const Text(
                'SP-2024-007',
                style: TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 30),

              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Personal Information',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey[800]),
                ),
              ),
              const SizedBox(height: 10),

              
              Card(
                elevation: 2,
                color: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Column(
                  children: [
                    _buildReadOnlyTile('Full Name', 'Ahmed Ali'),
                    _buildReadOnlyTile('Student ID', 'SP-2024-007'),
                    _buildReadOnlyTile('University Email', 'ahmed@iqra.edu.pk'),
                    _buildReadOnlyTile('Phone Number', '0300-1234567'),
                    _buildReadOnlyTile('Current Semester', 'Fall 2024'),
                  ],
                ),
              ),
             
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
  currentIndex: 2, // Highlights "Profile"
  type: BottomNavigationBarType.fixed,
  selectedItemColor: const Color(0xFF1A237E),
  unselectedItemColor: Colors.grey,
  showUnselectedLabels: true,
  onTap: (index) {
    if (index == 0) Navigator.pushNamed(context, '/dashboard');
    if (index == 1) Navigator.pushNamed(context, '/enrolled');
    if (index == 3) Navigator.pushNamed(context, '/settings');
  },
  items: const [
    BottomNavigationBarItem(icon: Icon(Icons.grid_view), label: 'Dashboard'),
    BottomNavigationBarItem(icon: Icon(Icons.book), label: 'Courses'),
    BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
    BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
  ],
),
    );
  }

  
  Widget _buildReadOnlyTile(String title, String value) {
    return ListTile(
      title: Text(title, style: const TextStyle(fontSize: 14, color: Colors.grey)),
      trailing: Text(
        value,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
      ),
    );
  }
}