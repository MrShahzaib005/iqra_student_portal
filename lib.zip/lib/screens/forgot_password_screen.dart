import 'package:flutter/material.dart';

class ForgotPasswordScreen extends StatelessWidget {
  const ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 60.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 40),
              Image.asset(
                'assets/iqra.png',
                height: 100,
                errorBuilder: (context, error, stackTrace) =>
                    const Icon(Icons.school, size: 100, color: Colors.blue),
              ), // [cite: 112]
              const SizedBox(height: 30),
              
              const Text(
                'FORGOT\nPASSWORD',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ), // [cite: 113]
              const SizedBox(height: 20),
              
              const Text(
                "Enter your email and we'll send you a link to reset your password.",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey),
              ), // [cite: 114]
              const SizedBox(height: 40),

              TextField(
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.email_outlined), // [cite: 116]
                  hintText: 'Email Address',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                    borderSide: BorderSide.none,
                  ),
                  filled: true,
                  fillColor: Colors.grey[100],
                ),
              ), // [cite: 115]
              const SizedBox(height: 40),

              TextButton(
                onPressed: () {
                  Navigator.pop(context); 
                },
                child: const Text('Remember your password? Log In'),
              ), // [cite: 117]
            ],
          ),
        ),
      ),
    );
  }
}